package com.perfulandia.Perfulandia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfulandiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
